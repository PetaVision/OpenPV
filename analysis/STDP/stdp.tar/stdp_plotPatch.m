function PATCH = stdp_plotPatch(fname, I, J)
% plot patch for neuron I, J 
global input_dir NK NO NX NY DTH 

filename = fname;
filename = [input_dir, filename];
N = NX * NY;

fid=fopen(filename,'r','native');
%     header
%     params[0] = nParams;
%     params[1] = nxp;
%     params[2] = nyp;
%     params[3] = nfp;
%     params[4] = (int) minVal;        // stdp value
%     params[5] = (int) ceilf(maxVal); // stdp value
%     params[6] = numPatches;
%
num_params = fread(fid, 1, 'int');
NXP = fread(fid, 1, 'int');
NYP = fread(fid, 1, 'int');
NFP = fread(fid, 1, 'int');
minVal = fread(fid, 1, 'int');
maxVal = fread(fid, 1, 'int');
numPatches = fread(fid, 1, 'int');
fprintf('num_params = %d NXP = %d NYP = %d NFP = %d ',...
    num_params,NXP,NYP,NFP);
fprintf('minVal = %f maxVal = %d numPatches = %d\n',...
    minVal,maxVal,numPatches);
    
patch_size = NXP*NYP;   


%colormap('gray');
colormap(jet);
b_color = 1;     % use to scale weights to the full range
                 % of the color map
a_color = (length(get(gcf,'Colormap'))-1.0)/maxVal;

a= (NXP-1)/2;    % NXP = 2a+1;
b= (NYP-1)/2;    % NYP = 2b+1;


PATCH = [];

n_time_steps = 0;

while (~feof(fid))
    for j=1:NY
        for i=1:NX
            
            nxp = fread(fid, 1, 'uint16'); % unsigned short
            nyp = fread(fid, 1, 'uint16'); % unsigned short
            w = fread(fid, patch_size+3, 'uchar'); % unsigned char

            if(i==I & j==J & ~isempty(w))
                w = minVal + (maxVal - minVal) * ( (w * 1.0)/ 255.0);
                A = reshape(w(1:patch_size), [NXP NYP]);
                PATCH =  [PATCH; w(1:patch_size)'];
                imagesc(a_color*A+b_color);
                pause(0.1)
            end
            
        end
    end
    n_time_steps = n_time_steps + 1;
    fprintf('%d\n',n_time_steps);
end


