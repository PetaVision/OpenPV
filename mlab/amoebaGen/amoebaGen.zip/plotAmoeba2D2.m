function plotAmoeba2D2(amoeba_image, amoeba_struct, trial_ndx, nfourier)

plotAmoebaPTB2(amoeba_image, amoeba_struct, trial_ndx, true, nfourier);
plotAmoebaPTB2(amoeba_image, amoeba_struct, trial_ndx, false, nfourier);
plotAmoebaR2(amoeba_image, amoeba_struct, trial_ndx, nfourier);
plotAmoebaPTB2(amoeba_image, amoeba_struct, trial_ndx, true, nfourier, true);


